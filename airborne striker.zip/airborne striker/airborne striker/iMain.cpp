/*
    Original Author: S. M. Shahriar Nirjon
    Last Modified by: Mohammad Saifur Rahman
    last modified: October 13, 2015
    Version: 2.0
*/




# include "iGraphics.h"
double x1 = 100, x2 = 250;
int scrx = 550, scry = 800;
int playerx = rand() % 550, playery = 0;
int planespeed = 10;
int bulletx, bullety, bulletflag = 0, bulletflag2 = 0, bulletspeed = 12, buttonvalid = 1;
int tempx, tempy;
int ene1x=0, ene2x=150, ene3x=300, ene4x=450, ene1y=800, ene2y=800, ene3y=800, ene4y=800;
int sp1=rand()%7, sp2=rand()%7, sp3=rand()%7, sp4=rand()%7;
int flag1 = 1, flag2 = 1, flag3 = 1, flag4 = 1;
int score=0;
char score2[999];
int dead = 4;
int colflag = 1;
char str[999], faild[4];
char name[999];
int Indexnumber = 0;
int songflag1 = 1, songflag2 = 1;
int mposx;
int mposy;

/*
	function iDraw() is called again and again by the system.
*/
void iDraw()
{
	iClear();
	if (songflag1 == 1 && dead != 0)
	{
		PlaySound("sources\\PlayMusic.wav", NULL, SND_LOOP | SND_ASYNC);
		songflag1 = 0;
	}
	iShowBMP(0, 0, "sources\\BG.bmp");
	iShowBMP2(playerx, playery, "sources\\1.bmp",0);
	if (playery < 0){
		playery = 0;
	}
	if (playery > 700){
		playery = 700;
	}
	if (playerx > 450){
		playerx = 450;
	}
	if (playerx <0){
		playerx = 0;
	}
	if (buttonvalid == 0)
	{
		iShowBMP2(bulletx, bullety, "sources\\bullet.bmp", 0);
		bullety = bullety + bulletspeed;
	}
	if (bullety>800){
		bullety = playery + 50;
		bulletx = playerx + 50;
		buttonvalid = 1;
	}

	if (flag1 == 1){
		ene1y -= sp1;
		iShowBMP2(ene1x, ene1y, "sources\\2.bmp", 0);
	}
	if (flag2 == 1){
		ene2y -= sp2;
		iShowBMP2(ene2x, ene2y, "sources\\3.bmp", 0);
	}
	if (flag3 == 1){
		ene3y -= sp3;
		iShowBMP2(ene3x, ene3y, "sources\\4.bmp", 0);
	}
	if (flag4 == 1){
		ene4y -= sp4;
		iShowBMP2(ene4x, ene4y, "sources\\5.bmp", 0);
	}
	if (ene1y  < 0){
		sp1 = rand() % 4 + 4;
		ene1y = scry + 600;
		flag1 = 1;
	}
	if (ene2y  < 0){
		sp2 = rand() % 4 + 4;
		ene2y = scry + 600;
		flag2 = 1;
	}
	if (ene3y  < 0){
		sp3 = rand() % 4 + 4;
		ene3y = scry + 600;
		flag3 = 1;
	}
	if (ene4y  < 0){
		sp4 = rand() % 4 + 4;
		ene4y = scry + 600;
		flag4 = 1;
	}
	if ((playerx>=ene1x && playerx+100<=ene1x+100)&& (playerx+100>=ene1x&&playerx+100<=ene1x+100)&&(playery+100>=ene1y&&playery+100<=ene1y+100)){
		printf("collision ");
		playery = 0;
		ene1y = -1;
		flag1 = 0;
		dead--;
	}
	if ((playerx >= ene2x && playerx + 100 <= ene2x + 100) && (playerx + 100 >= ene2x&&playerx + 100 <= ene2x + 100) && (playery + 100 >= ene2y&&playery + 100 <= ene1y + 100)){
		printf("collision ");
		playery = 0;
		ene2y = -1;
		flag1 = 0;
		dead--;
	}
	if ((playerx >= ene3x && playerx + 100 <= ene3x + 100) && (playerx + 100 >= ene3x&&playerx + 100 <= ene3x + 100) && (playery + 100 >= ene3y&&playery + 100 <= ene1y + 100)){
		printf("collision ");
		playery = 0;
		ene3y = -1;
		flag1 = 0;
		dead--;
	}
	if ((playerx >= ene4x && playerx + 100 <= ene4x + 100) && (playerx + 100 >= ene4x&&playerx + 100 <= ene4x + 100) && (playery + 100 >= ene4y&&playery + 100 <= ene1y + 100)){
		printf("collision ");
		playery = 0;
		ene4y = -1;
		flag1 = 0;
		dead--;
	}
	if ((bulletx + 10 >= ene1x && bulletx + 10 <= ene1x + 100) && (bullety + 30 >= ene1y && bullety + 30 <= ene1y + 100)){
		score++;
		ene1y = -1;
		flag1 = 0;
	}
	if ((bulletx + 10 >= ene2x && bulletx + 10 <= ene2x + 100) && (bullety + 30 >= ene2y && bullety + 30 <= ene2y + 100)){
		score++;
		ene2y = -1;
		flag2 = 0;


	}
	if ((bulletx + 10 >= ene3x && bulletx + 10 <= ene3x + 100) && (bullety + 30 >= ene3y && bullety + 30 <= ene3y + 100)){
		score++;
		ene3y = -1;
		flag3 = 0;

	}
	if ((bulletx + 10 >= ene4x && bulletx + 10 <= ene4x + 100) && (bullety + 30 >= ene4y && bullety + 30 <= ene4y + 100)){
		score++;
		ene4y = -1;
		flag4 = 0;

	}
	_itoa_s(dead, faild, 10);
	_itoa_s(score, str, 10);
	iSetColor(254, 239, 57);
	iText(500, 750, str, GLUT_BITMAP_TIMES_ROMAN_24);
	iSetColor(254, 239, 57);
	iText(20, 750, faild, GLUT_BITMAP_TIMES_ROMAN_24);
	if (dead <=0)
	{
		ene1y = 550, ene2y = 550, ene3y = 550, ene4y = 550;
		bullety = -50;
		iShowBMP(0, 0, "sources\\jisan.bmp");
		iText(x1, x2, name, GLUT_BITMAP_HELVETICA_18);
		iText(x1+250 ,x2, str, GLUT_BITMAP_HELVETICA_18);
		iText(x1, x2 - 100, "Press 'R' To Play again", GLUT_BITMAP_TIMES_ROMAN_24);
	}
	if (songflag2 == 1 && dead == 0)
	{
		PlaySound("sources\\GameOver.wav", NULL, SND_LOOP | SND_ASYNC);
		songflag2 = 0;
	}


}

/*
	function iMouseMove() is called when the user presses and drags the mouse.
	(mx, my) is the position where the mouse pointer is.
*/
void iMouseMove(int mx, int my)
{
	//place your codes here
}

/*
	function iMouse() is called when the user presses/releases the mouse.
	(mx, my) is the position where the mouse pointer is.
*/
void iMouse(int button, int state, int mx, int my)
{
	if(button == GLUT_LEFT_BUTTON && state == GLUT_DOWN)
	{
		//place your codes here
	}
	if(button == GLUT_RIGHT_BUTTON && state == GLUT_DOWN)
	{
		//place your codes here
	}
}
/*iPassiveMouseMove is called to detect and use
the mouse point without pressing any button */

void iPassiveMouseMove(int mx,int my)
{
	//place your code here

 mposx = mx;
 mposy = my;
 if(mx== 2){}        /*Something to do with mx*/
 else if(my== 2){}   /*Something to do with my*/

}

/*
	function iKeyboard() is called whenever the user hits a key in keyboard.
	key- holds the ASCII value of the key pressed.
*/
void iKeyboard(unsigned char key)
{


	if (key == 'r' && dead <= 0)
	{
		dead = 4;
		score = 0;
	}
	if (key == 'x' && buttonvalid==1)
	{
		bulletx = playerx+40;
		bullety = playery+50;
		buttonvalid = 0;
	}
	//place your codes for other keys here
}

/*
	function iSpecialKeyboard() is called whenver user hits special keys like-
	function keys, home, end, pg up, pg down, arraows etc. you have to use
	appropriate constants to detect them. A list is:
	GLUT_KEY_F1, GLUT_KEY_F2, GLUT_KEY_F3, GLUT_KEY_F4, GLUT_KEY_F5, GLUT_KEY_F6,
	GLUT_KEY_F7, GLUT_KEY_F8, GLUT_KEY_F9, GLUT_KEY_F10, GLUT_KEY_F11, GLUT_KEY_F12,
	GLUT_KEY_LEFT, GLUT_KEY_UP, GLUT_KEY_RIGHT, GLUT_KEY_DOWN, GLUT_KEY_PAGE UP,
	GLUT_KEY_PAGE DOWN, GLUT_KEY_HOME, GLUT_KEY_END, GLUT_KEY_INSERT
*/
void iSpecialKeyboard(unsigned char key)
{
	if (key == GLUT_KEY_RIGHT  )
	{
		if (playerx<450){
			playerx = playerx + planespeed;
		}
	}
	if (key == GLUT_KEY_LEFT)
	{
		if (playerx> 0){
			playerx = playerx - planespeed;
		}
	}

	if(key == GLUT_KEY_DOWN)
	{
		if (playery > 0){
			playery = playery - planespeed;
		}
	}
	if (key == GLUT_KEY_UP)
	{
		if (playery <750){
			playery = playery + planespeed;
		}
	}
	//place your codes for other keys here
}
//
int main()
{
	//place your own initialization codes here.
	system("MODE CON COLS=50 LINES=25");
	system("color 25");
	printf_s("Enter Your Name\n");
	gets_s(name);
	iInitialize(scrx, scry, "Airbone Strike");
	return 0;
}
